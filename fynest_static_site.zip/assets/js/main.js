// main.js
function openWhatsApp(product){
  const number = "919610037389";
  const text = encodeURIComponent("Hi, I'm interested in this product: " + product + ". Please share details.");
  const url = "https://wa.me/" + number + "?text=" + text;
  window.open(url, "_blank");
}