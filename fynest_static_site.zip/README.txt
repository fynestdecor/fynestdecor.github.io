Fynest static site - Instructions to publish on GitHub Pages
1. Create a repository named: fynestdecor.github.io (or any name)
2. Upload all files from this ZIP into the repo root. Ensure folder structure (assets/) is preserved.
3. Commit & push.
4. Go to Settings -> Pages -> Deploy from a branch -> Branch: main (root) -> Save.
5. Wait 1-2 minutes and open: https://<your-username>.github.io/<repo-name> or https://<your-username>.github.io if repo named as <username>.github.io
6. To update products: edit /products.html or replace images in assets/images and re-upload.